# LogiGO_BusinessApp_
LogiGO is a business app designed for logistics companies, helping to maintain an optimized flow of shipments, routes, returns, reports, inventory, and employee management. LogiGO was created to provide fast and sustainable solutions for the logistics sector, streamlining operations and improving overall efficiency.

Application built on Java/Spring, Mysql, Redis, React and Next.JS.
